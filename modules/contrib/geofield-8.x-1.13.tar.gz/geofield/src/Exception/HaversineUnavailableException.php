<?php

namespace Drupal\geofield\Exception;

/**
 * Defines 'haversine is unavailable' exception class.
 */
class HaversineUnavailableException extends \UnexpectedValueException {

}
