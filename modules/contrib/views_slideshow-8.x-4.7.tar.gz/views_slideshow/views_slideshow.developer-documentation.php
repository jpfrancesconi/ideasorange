<?php

/**
 * @file
 * Provides API homepage for Views Slideshow.
 */

/**
 * Views slide show.
 *
 * @mainpage Views Slideshow API & Developer Documentation
 * Welcome to the Views Slideshow developer's documentation.
 *
 * Newcomers to Drupal development should read the conceptual information
 * in @link https://www.drupal.org/docs/8/api/ Drupal API Introduction @endlink
 * or @link https://api.drupal.org/api/drupal/8.2.x Drupal API Docs @endlink.
 * The heavily documented
 * @link https://api.drupal.org/api/examples/8.x-1.x Example modules @endlink
 * may also be helpful.
 *
 * For tutorials and examples for acheiving specific tasks, also see the
 * @link https://drupal.org/docs/8/modules/views-slideshow/developer-tutorials Developer Guide @endlink.
 *
 * For any comments, support or questions see the
 * @link https://drupal.org/project/views_slideshow module page @endlink.
 * Also, feel free to comment here if it is specific to one function/file.
 *
 * - Primary components of Views Slideshow
 *   - @link vss_theme Theme Functions @endlink
 *   - @link vss_templates Templates @endlink
 *   - @link modules/views_slideshow_cycle/views_slideshow_cycle.module Cycle Module @endlink
 */
